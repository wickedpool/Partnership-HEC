
<div class="clear"></div>
</div>
<footer role="contentinfo">
<?php wp_footer(); ?>
<?php wp_nav_menu( array( 'theme_location' => 'main-menu' ) ); ?>
</footer>
</div>
</body>
</html>
